import React, { useState } from "react";
import ReactDOM from "react-dom";

const App = () => {
  const [words, setWords] = useState([]);
  const [occurrences, setOccurrences] = useState([]);

  const handleSubmit = () => {
    fetch("https://www.terriblytinytales.com/test.txt")
      .then((response) => response.text())
      .then((text) => {
        const words = text.split(" ");
        const occurrences = words.reduce((acc, word) => {
          acc[word] = (acc[word] || 0) + 1;
          return acc;
        }, {});

        setWords(Object.keys(occurrences));
        setOccurrences(Object.values(occurrences));
      });
  };

  const renderHistogram = () => {
    const data = [
      { x: words[0], y: occurrences[0] },
      { x: words[1], y: occurrences[1] },
      { x: words[2], y: occurrences[2] },
      { x: words[3], y: occurrences[3] },
      { x: words[4], y: occurrences[4] },
      { x: words[5], y: occurrences[5] },
      { x: words[6], y: occurrences[6] },
      { x: words[7], y: occurrences[7] },
      { x: words[8], y: occurrences[8] },
      { x: words[9], y: occurrences[9] },
      { x: words[10], y: occurrences[10] },
      { x: words[11], y: occurrences[11] },
      { x: words[12], y: occurrences[12] },
      { x: words[13], y: occurrences[13] },
      { x: words[14], y: occurrences[14] },
      { x: words[15], y: occurrences[15] },
      { x: words[16], y: occurrences[16] },
      { x: words[17], y: occurrences[17] },
      { x: words[18], y: occurrences[18] },
      { x: words[19], y: occurrences[19] },
    ];

    return (
      <div>
        <h1>Histogram of the 20 most occurring words</h1>
        <canvas id="myChart" width="500" height="500"></canvas>
      </div>
    );
  };

  const exportCSV = () => {
    const csv = `
      word,occurrences
      ${words.join(",")},${occurrences.join(",")}
    `;

    const blob = new Blob([csv], { type: "text/csv" });

    const link = document.createElement("a");
    link.href = window.URL.createObjectURL(blob);
    link.download = "histogram.csv";
    link.click();
  };

  return (
    <div>
      <button onClick={handleSubmit}>Submit</button>
      {words.length > 0 && renderHistogram()}
      <button onClick={exportCSV}>Export</button>
    </div>
  );
};

export default App;
